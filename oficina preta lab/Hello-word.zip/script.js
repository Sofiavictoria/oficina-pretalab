alert("Olá Mundo!")

prompt("Digite seu nome:")